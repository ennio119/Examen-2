package com.example.waveoffoodadmin.model

data class LoginModel(
    var id: String = "",
    var email: String = "",
    var password: String = "",
    var name: String = "",
    var address: String = "",
    var phone: String = ""
)
